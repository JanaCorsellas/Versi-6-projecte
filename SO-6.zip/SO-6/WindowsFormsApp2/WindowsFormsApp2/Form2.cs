﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public static Form2 instance;
        public Label l1;
        public Label l2;
        public Label l3;
        public Label l4;
        public Label l5;
        public Label l6;
        public Label l7;
        public Label l8;
        public TextBox tB;

        public Form2()
        {
            InitializeComponent();
            instance = this;
            l1 = label6;
            l2 = label8;
            l3 = label7;
            l4 = label1;
            l5 = label2;
            l6 = label3;
            l7 = label4;
            l8 = label5;
            tB = textBox1;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            panel1.Invalidate();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1.instance.enviarMensaje();
            textBox1.Clear();
        }

        private void Panel_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics g = e.Graphics;

            Pen mypen = new Pen(Color.Red);

            Rectangle r = new Rectangle(label5.Left, label5.Top, 130, 60);
            g.DrawRectangle(Pens.Blue, r);
            Rectangle r1 = new Rectangle(label6.Left, label6.Top, 130, 60);
            g.DrawRectangle(Pens.Blue, r1);
            Rectangle r2 = new Rectangle(label7.Left, label7.Top, 130, 60);
            g.DrawRectangle(Pens.Blue, r2);
            Rectangle r3 = new Rectangle(label8.Left, label8.Top, 130, 60);
            g.DrawRectangle(Pens.Blue, r3);
        }
    }
}

